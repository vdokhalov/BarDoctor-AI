@echo off
setlocal
title BarDoctor Local Connector Setup
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
if errorlevel 1 (
  echo.
  echo Installation failed. Read the message above or send setup.log to BarDoctor support.
  pause
  exit /b 1
)
exit /b 0
